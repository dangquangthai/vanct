# frozen_string_literal: true

require_relative 'base_model'

class TableLine < BaseModel
  def initialize(table_no:, product_name:, product_no:, amount:, price:, unit:, product_group:, order_time:, da_bao:)
    @table_no = table_no
    @product_name = product_name
    @product_no = product_no
    @amount = amount
    @price = price
    @unit = unit
    @product_group = product_group
    @order_time = order_time
    @da_bao = da_bao
    @total = amount * price
  end

  attr_reader :table_no,
              :product_name,
              :product_no,
              :amount,
              :price,
              :unit,
              :product_group,
              :order_time,
              :da_bao,
              :total
end
